# Product

<!-- impeccable:product-schema 1 -->

## Platform

web (WordPress admin)

## Users
WordPress site administrators who want to bulk-generate and schedule SEO blog posts from the dashboard without leaving WP. Indonesian-speaking operators; content published to a general-interest Indonesian site.

## Product Purpose
Add an "Auto Generated Content" submenu under the WordPress Posts menu. Admin fills a short Indonesian form, authenticates with Puter JS native login, and the plugin generates N complete Indonesian articles via Puter AI, then schedules them one per day via WP-Cron/native post dates.

## Positioning
Native Puter JS login + Puter AI text generation inside the WP dashboard itself — no API keys, no third-party accounts beyond Puter. One-post-per-day automatic scheduling built on WP-Cron and native post statuses (`future`/`publish`).

## Operating Context
WordPress admin on Posts > Auto Generated Content. Single-file plugin. UI and all generated content in Indonesian. Admin clicks "Buat Konten Otomatis", real-time progress, then success notification listing scheduled posts.

## Capabilities and Constraints
- Enqueue Puter JS (`https://js.puter.com/v2/`) on the admin page.
- Indonesian UI: form inputs (topic/instructions, count, tone), submit button "Buat Konten Otomatis".
- Puter `puter.ai.chat()` generates complete articles (title, HTML body ≥500 words, auto category, 3-5 tags) in a structured format.
- AJAX to admin-ajax.php backend handler with nonce, sanitizes all inputs.
- Schedules posts: first `publish` today, rest `future` at +1 day each via DAY_IN_SECONDS/WP datestamp.
- Secure inputs (`sanitize_*`), escaped outputs (`esc_html`/`esc_attr`), nonces for AJAX.

Explicitly undecided: full UI color/style direction (admin panel — treated as Operate; default WP admin theming with restrained accents is acceptable); whether first post publishes immediately vs all future. Default chosen: first publishes today.

## Brand Commitments
UI language fixed to Indonesian. Single-file plugin with header (Name WP Puter AI Auto Content, Description, Version, Author). Submenu slug `wp-puter-auto-content` under Posts.

## Evidence on Hand
None beyond the user's functional spec. No real generated content yet; synthetic only.

## Product Principles
1. Single-file, no dependencies beyond Puter JS loaded from its CDN.
2. Native WP primitives (wp-cron, wp_insert_post, post statuses) over custom scheduling.
3. Every trusted input sanitized, every output escaped, AJAX nonce-protected.
4. Indonesian end-to-end: UI, notifications, generated articles.

## Accessibility & Inclusion
Standard WP admin form semantics: labels tied to inputs, keyboard operable controls, visible focus. No product-specific requirement beyond the admin form.

## Design decisions (inferred, labeled)
- No structured question/decision tool and no image generation available in this session; code-led path taken without asking. Admin panel is an Operate surface; expression stays subordinate to the task.
- Visual direction: clean WP-native admin form, restrained palette, one accent for the primary action and status states. No brand world invented.
