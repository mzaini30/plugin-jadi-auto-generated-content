<?php
/**
 * Plugin Name: WP Puter AI Auto Content
 * Description: Buat konten otomatis dengan Puter JS — isi API Key Puter, generate artikel lengkap berbahasa Indonesia, dan jadwalkan satu post per hari lewat WP-Cron.
 * Version: 1.1.0
 * Author: Tim Developer
 * Text Domain: wp-puter-auto-content
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WP_PUTER_AC_VERSION', '1.1.0' );
define( 'WP_PUTER_AC_SLUG', 'wp-puter-auto-content' );
define( 'WP_PUTER_AC_AJAX', 'wp_puter_ac_schedule' );

/**
 * Registrasi submenu "Auto Generated Content" di bawah menu Posts.
 */
function wp_puter_ac_menu() {
	add_submenu_page(
		'edit.php',
		__( 'Auto Generated Content', 'wp-puter-auto-content' ),
		__( 'Auto Generated Content', 'wp-puter-auto-content' ),
		'edit_posts',
		WP_PUTER_AC_SLUG,
		'wp_puter_ac_render_page'
	);
}
add_action( 'admin_menu', 'wp_puter_ac_menu' );

/**
 * Enqueue Puter JS + inline script admin (satu file).
 */
function wp_puter_ac_enqueue( $hook ) {
	if ( strpos( $hook, WP_PUTER_AC_SLUG ) === false ) {
		return;
	}
	wp_enqueue_script( 'puter-js', 'https://js.puter.com/v2/', array( 'jquery' ), null, true );

	$config = array(
		'ajaxUrl' => admin_url( 'admin-ajax.php' ),
		'nonce'   => wp_create_nonce( 'wp_puter_ac_nonce' ),
		'action'  => WP_PUTER_AC_AJAX,
	);

	$js = <<<'JAVASCRIPT'
(function ($) {
	'use strict';

	var cfg = window.wpPuterAc || {};
	var $statusDot = $('#wp-puter-ac-status-dot');
	var $statusText = $('#wp-puter-ac-status-text');
	var $apiKeyInput = $('#wp-puter-ac-api-key');
	var $submitBtn = $('#wp-puter-ac-submit');
	var $progress = $('#wp-puter-ac-progress');
	var $barFill = $('#wp-puter-ac-bar-fill');
	var $progressText = $('#wp-puter-ac-progress-text');
	var $result = $('#wp-puter-ac-result');

	function updateStatus() {
		var key = $apiKeyInput.val().trim();
		var hasKey = key.length > 0;
		$statusDot.removeClass('dot-on dot-off').addClass(hasKey ? 'dot-on' : 'dot-off');
		$statusText.text(hasKey ? 'Terhubung dengan Puter (API Key Tersedia)' : 'Belum Terhubung (API Key Kosong)');
		$submitBtn.prop('disabled', !hasKey);
		if (hasKey && typeof puter !== 'undefined') {
			puter.authToken = key;
		}
	}

	$apiKeyInput.on('input change', updateStatus);
	updateStatus();

	// Submit form.
	$('#wp-puter-ac-form').on('submit', function (e) {
		e.preventDefault();
		var apiKey = $apiKeyInput.val().trim();
		if (!apiKey) {
			alert('Silakan masukkan Puter API Key terlebih dahulu.');
			return;
		}

		if (typeof puter !== 'undefined') {
			puter.authToken = apiKey;
		}

		var topic = $('#wp-puter-ac-topic').val().trim();
		var count = parseInt($('#wp-puter-ac-count').val(), 10) || 10;
		var tone = $('#wp-puter-ac-tone').val();

		if (!topic) {
			alert('Topik / Pembahasan Utama wajib diisi.');
			return;
		}

		$submitBtn.prop('disabled', true);
		$result.attr('hidden', true);
		setProgress(5, 'Mengirim perintah ke Puter AI...');

		var prompt = 'Kamu adalah penulis konten profesional Indonesia. Buatkan ' + count
			+ ' artikel lengkap berbahasa Indonesia, siap terbit di WordPress, dengan topik utama: "'
			+ topic + '". Nada bicara: ' + tone + '.\n\n'
			+ 'WAJIB untuk setiap artikel:\n'
			+ '1. judul: judul menarik, SEO-friendly\n'
			+ '2. content: isi artikel lengkap minimal 500 kata, format HTML (gunakan <p>, <h2>, <ul>, <li>), informatif, menarik, dan akurat\n'
			+ '3. category: satu nama kategori yang relevan\n'
			+ '4. tags: 3-5 tag relevan, dipisah koma\n\n'
			+ 'Keluarkan persis JSON array, contoh:[{"title":"...","content":"<p>...</p>","category":"...","tags":"tag1, tag2, tag3"}]\n'
			+ 'Jangan tambahkan teks lain di luar JSON.';

		puter.ai.chat(prompt).then(function (res) {
			var text = (res && (res.message && res.message.content || res.message)) ? (res.message.content || res.message) : String(res);
			var posts = wpPuterAcParseJson(text);

			if (!posts || !posts.length) {
				setProgress(100, 'Gagal membaca hasil dari Puter. Coba lagi.');
				$submitBtn.prop('disabled', false);
				$result.attr('hidden', false).html('<p class="wp-puter-ac-error">Gagal membaca hasil dari Puter AI. Pastikan API Key valid.</p>');
				return;
			}

			setProgress(60, 'Menyimpan dan menjadwalkan ' + posts.length + ' konten...');

			$.post(cfg.ajaxUrl, {
				action: cfg.action,
				nonce: cfg.nonce,
				posts: JSON.stringify(posts)
			}).done(function (resp) {
				if (!resp || !resp.success) {
					var msg = (resp && resp.data && resp.data.message) ? resp.data.message : 'Terjadi kesalahan server.';
					setProgress(100, msg);
					$result.attr('hidden', false).html('<p class="wp-puter-ac-error">' + msg + '</p>');
					return;
				}

				setProgress(100, resp.data.message);
				var list = '';
				if (resp.data.posts) {
					list = '<ul class="wp-puter-ac-result-list">';
					$.each(resp.data.posts, function (i, p) {
						list += '<li><strong>' + p.title + '</strong> — ' + p.status + ' pada ' + p.date + '</li>';
					});
					list += '</ul>';
				}
				$result.attr('hidden', false).html('<p class="wp-puter-ac-success">' + resp.data.message + '</p>' + list);
			}).fail(function () {
				setProgress(100, 'Gagal terhubung ke server.');
				$result.attr('hidden', false).html('<p class="wp-puter-ac-error">Gagal terhubung ke server. Coba lagi.</p>');
			}).always(function () {
				$submitBtn.prop('disabled', false);
			});
		}).catch(function (err) {
			setProgress(100, 'Terjadi kesalahan dari Puter AI.');
			$result.attr('hidden', false).html('<p class="wp-puter-ac-error">Terjadi kesalahan dari Puter AI: ' + (err ? (err.message || String(err)) : 'tidak diketahui') + '</p>');
			$submitBtn.prop('disabled', false);
		});
	});

	function setProgress(pct, text) {
		$progress.attr('hidden', false);
		$barFill.css('width', pct + '%');
		$progressText.text(text || '');
	}

	function wpPuterAcParseJson(text) {
		if (!text) { return null; }
		var start = text.indexOf('[');
		var end = text.lastIndexOf(']');
		if (start === -1 || end <= start) { return null; }
		try {
			return JSON.parse(text.slice(start, end + 1));
		} catch (e) {
			return null;
		}
	}
})(jQuery);
JAVASCRIPT;

	wp_add_inline_script( 'puter-js', 'var wpPuterAc = ' . wp_json_encode( $config ) . ';', 'before' );
	wp_add_inline_script( 'puter-js', $js );
}
add_action( 'admin_enqueue_scripts', 'wp_puter_ac_enqueue' );

/**
 * Render halaman admin.
 */
function wp_puter_ac_render_page() {
	?>
	<div class="wrap wp-puter-ac-wrap">
		<h1><?php esc_html_e( 'Auto Generated Content', 'wp-puter-auto-content' ); ?></h1>
		<p class="wp-puter-ac-sub"><?php esc_html_e( 'Buat dan jadwalkan artikel lengkap berbahasa Indonesia dengan Puter AI — satu post per hari.', 'wp-puter-auto-content' ); ?></p>

		<!-- Koneksi Puter via API Key -->
		<div class="wp-puter-ac-card">
			<h2><?php esc_html_e( 'Konfigurasi Puter API Key', 'wp-puter-auto-content' ); ?></h2>
			<div class="wp-puter-ac-status">
				<span id="wp-puter-ac-status-dot" class="dot dot-off"></span>
				<span id="wp-puter-ac-status-text"><?php esc_html_e( 'Belum Terhubung (API Key Kosong)', 'wp-puter-auto-content' ); ?></span>
			</div>
			
			<p class="wp-puter-ac-field" style="margin-top:12px;">
				<label for="wp-puter-ac-api-key"><?php esc_html_e( 'Puter API Key / Auth Token', 'wp-puter-auto-content' ); ?></label>
				<input type="password" id="wp-puter-ac-api-key" placeholder="<?php esc_attr_e( 'Masukkan API Key Puter Anda di sini...', 'wp-puter-auto-content' ); ?>" style="width:100%;max-width:520px;" />
			</p>
			
			<p class="wp-puter-ac-hint">
				<?php esc_html_e( 'Belum punya API Key?', 'wp-puter-auto-content' ); ?>
				<a href="https://puter.com/#account" target="_blank" rel="noopener noreferrer" class="button button-secondary" style="margin-left:8px;">
					<?php esc_html_e( 'Dapatkan API Key Puter', 'wp-puter-auto-content' ); ?> &rarr;
				</a>
			</p>
		</div>

		<!-- Form konfigurasi -->
		<form id="wp-puter-ac-form" class="wp-puter-ac-card">
			<h2><?php esc_html_e( 'Pengaturan Konten', 'wp-puter-auto-content' ); ?></h2>

			<p class="wp-puter-ac-field">
				<label for="wp-puter-ac-topic"><?php esc_html_e( 'Topik / Pembahasan Utama', 'wp-puter-auto-content' ); ?></label>
				<textarea id="wp-puter-ac-topic" name="topic" rows="4" required
					placeholder="<?php esc_attr_e( 'Contoh: tips memulai bisnis online untuk pemula di Indonesia', 'wp-puter-auto-content' ); ?>"></textarea>
			</p>

			<p class="wp-puter-ac-field">
				<label for="wp-puter-ac-count"><?php esc_html_e( 'Jumlah Konten yang Ingin Dibuat', 'wp-puter-auto-content' ); ?></label>
				<input type="number" id="wp-puter-ac-count" name="count" value="10" min="1" max="50" required />
			</p>

			<p class="wp-puter-ac-field">
				<label for="wp-puter-ac-tone"><?php esc_html_e( 'Nada Bicara / Gaya Bahasa', 'wp-puter-auto-content' ); ?></label>
				<select id="wp-puter-ac-tone" name="tone">
					<option value="Informatif dan Santai" selected><?php esc_html_e( 'Informatif dan Santai', 'wp-puter-auto-content' ); ?></option>
					<option value="Formal dan Profesional"><?php esc_html_e( 'Formal dan Profesional', 'wp-puter-auto-content' ); ?></option>
					<option value="Ramah dan Memotivasi"><?php esc_html_e( 'Ramah dan Memotivasi', 'wp-puter-auto-content' ); ?></option>
					<option value="Energik dan Persuasif"><?php esc_html_e( 'Energik dan Persuasif', 'wp-puter-auto-content' ); ?></option>
				</select>
			</p>

			<p class="wp-puter-ac-submit">
				<button type="submit" id="wp-puter-ac-submit" class="button button-primary button-hero" disabled>
					<?php esc_html_e( 'Buat Konten Otomatis', 'wp-puter-auto-content' ); ?>
				</button>
			</p>
		</form>

		<!-- Progress -->
		<div id="wp-puter-ac-progress" class="wp-puter-ac-card" hidden>
			<h2><?php esc_html_e( 'Proses Pembuatan Konten', 'wp-puter-auto-content' ); ?></h2>
			<div class="wp-puter-ac-bar"><span id="wp-puter-ac-bar-fill"></span></div>
			<p id="wp-puter-ac-progress-text" class="wp-puter-ac-status-msg"></p>
		</div>

		<!-- Notifikasi hasil -->
		<div id="wp-puter-ac-result" class="wp-puter-ac-card" hidden></div>
	</div>
	<?php
}

/**
 * Backend AJAX: terima daftar post dari JS, jadwalkan memakai native post dates.
 */
function wp_puter_ac_schedule_posts() {
	check_ajax_referer( 'wp_puter_ac_nonce', 'nonce' );

	if ( ! current_user_can( 'edit_posts' ) ) {
		wp_send_json_error( array( 'message' => __( 'Anda tidak punya izin untuk membuat post.', 'wp-puter-auto-content' ) ) );
	}

	$posts = isset( $_POST['posts'] ) ? json_decode( wp_unslash( $_POST['posts'] ), true ) : array();

	if ( ! is_array( $posts ) || empty( $posts ) ) {
		wp_send_json_error( array( 'message' => __( 'Tidak ada konten yang diterima dari Puter.', 'wp-puter-auto-content' ) ) );
	}

	$user_id    = get_current_user_id();
	$author_id  = $user_id ? $user_id : 1;
	$publish_ts = current_time( 'timestamp' );
	$scheduled  = array();

	foreach ( $posts as $index => $post_data ) {
		if ( ! is_array( $post_data ) ) {
			continue;
		}

		$title   = isset( $post_data['title'] ) ? sanitize_text_field( $post_data['title'] ) : '';
		$content = isset( $post_data['content'] ) ? wp_kses_post( $post_data['content'] ) : '';

		if ( empty( $title ) || empty( $content ) ) {
			continue;
		}

		// Kategori otomatis (buat jika belum ada).
		$cat_ids = array();
		if ( ! empty( $post_data['category'] ) ) {
			$cat_name = sanitize_text_field( $post_data['category'] );
			$term     = term_exists( $cat_name, 'category' );
			if ( $term ) {
				$cat_ids[] = is_array( $term ) ? (int) $term['term_id'] : (int) $term;
			} else {
				$new = wp_insert_term( $cat_name, 'category' );
				if ( ! is_wp_error( $new ) ) {
					$cat_ids[] = (int) $new['term_id'];
				}
			}
		}

		// Tags (3-5, dipisah koma).
		$tags = array();
		if ( ! empty( $post_data['tags'] ) ) {
			foreach ( explode( ',', $post_data['tags'] ) as $tag ) {
				$tag = sanitize_text_field( trim( $tag ) );
				if ( $tag !== '' ) {
					$tags[] = $tag;
				}
			}
		}

		$scheduled_time = $publish_ts + ( $index * DAY_IN_SECONDS );
		$post_id        = wp_insert_post(
			array(
				'post_title'    => $title,
				'post_content'  => $content,
				'post_status'   => ( 0 === $index ) ? 'publish' : 'future',
				'post_date'     => date( 'Y-m-d H:i:s', $scheduled_time ),
				'post_date_gmt' => get_gmt_from_date( date( 'Y-m-d H:i:s', $scheduled_time ) ),
				'post_author'   => $author_id,
				'post_category' => $cat_ids,
				'tags_input'    => $tags,
			),
			true
		);

		if ( ! is_wp_error( $post_id ) ) {
			$scheduled[] = array(
				'id'     => $post_id,
				'title'  => $title,
				'status' => ( 0 === $index ) ? 'publish' : 'future',
				'date'   => date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $scheduled_time ),
				'url'    => ( 0 === $index ) ? get_permalink( $post_id ) : get_edit_post_link( $post_id, '' ),
			);
		}
	}

	if ( empty( $scheduled ) ) {
		wp_send_json_error( array( 'message' => __( 'Gagal menjadwalkan post. Periksa hasil dari Puter.', 'wp-puter-auto-content' ) ) );
	}

	wp_send_json_success(
		array(
			'message' => sprintf(
				/* translators: %d: jumlah post */
				__( 'Berhasil! %d konten berhasil dibuat dan dijadwalkan.', 'wp-puter-auto-content' ),
				count( $scheduled )
			),
			'posts'   => $scheduled,
		)
	);
}
add_action( 'wp_ajax_' . WP_PUTER_AC_AJAX, 'wp_puter_ac_schedule_posts' );

/**
 * Styling admin halaman plugin.
 */
function wp_puter_ac_admin_css( $hook ) {
	if ( strpos( $hook, WP_PUTER_AC_SLUG ) === false ) {
		return;
	}
	?>
	<style>
		.wp-puter-ac-wrap{max-width:760px}
		.wp-puter-ac-sub{color:#646970;margin-top:0}
		.wp-puter-ac-card{background:#fff;border:1px solid #dcdcde;border-radius:4px;padding:20px 24px;margin:16px 0;box-shadow:0 1px 3px rgba(0,0,0,.04)}
		.wp-puter-ac-card h2{margin-top:0;font-size:16px}
		.wp-puter-ac-hint{color:#646970;margin:8px 0}
		.wp-puter-ac-status{display:flex;align-items:center;gap:8px;font-weight:600;margin:8px 0}
		.wp-puter-ac-status .dot{width:12px;height:12px;border-radius:50%;display:inline-block}
		.dot-on{background:#00a32a;box-shadow:0 0 0 4px rgba(0,163,42,.15)}
		.dot-off{background:#d63638;box-shadow:0 0 0 4px rgba(214,54,56,.12)}
		.wp-puter-ac-field{margin:0 0 16px}
		.wp-puter-ac-field label{display:block;font-weight:600;margin-bottom:6px}
		.wp-puter-ac-field textarea,.wp-puter-ac-field input[type=number],.wp-puter-ac-field select{width:100%;max-width:520px}
		.wp-puter-ac-submit{margin:8px 0 0}
		.wp-puter-ac-bar{background:#f0f0f1;border-radius:8px;height:18px;overflow:hidden;margin:12px 0}
		.wp-puter-ac-bar span{display:block;height:100%;width:0;background:#2271b1;transition:width .3s ease}
		.wp-puter-ac-status-msg{margin:8px 0 0;font-style:italic}
		.wp-puter-ac-result-list{list-style:disc;padding-left:20px;margin:10px 0 0}
		.wp-puter-ac-result-list li{margin:4px 0}
		.wp-puter-ac-error{color:#d63638;font-weight:600}
		.wp-puter-ac-success{color:#00a32a;font-weight:600}
	</style>
	<?php
}
add_action( 'admin_head', 'wp_puter_ac_admin_css' );
